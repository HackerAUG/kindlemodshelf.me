#!/bin/sh
# Name: 2048
# DontUseFBInk

SOURCE_DIR="/mnt/us/documents/2048"
TARGET_DIR="/var/local/mesquite/2048"
DB="/var/local/appreg.db"
APP_ID="com.you.kindle2048"

if [ -d "$SOURCE_DIR" ]; then
  rm -rf "$TARGET_DIR"
  cp -r "$SOURCE_DIR" "$TARGET_DIR"
else
  exit 1
fi

sqlite3 "$DB" <<EOF
INSERT OR IGNORE INTO interfaces(interface) VALUES('application');
INSERT OR IGNORE INTO handlerIds(handlerId) VALUES('$APP_ID');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','lipcId','$APP_ID');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','command','/usr/bin/mesquite -l $APP_ID -c file://$TARGET_DIR/');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','supportedOrientation','U');
EOF

sleep 2
nohup lipc-set-prop com.lab126.appmgrd start app://$APP_ID >/dev/null 2>&1 &
